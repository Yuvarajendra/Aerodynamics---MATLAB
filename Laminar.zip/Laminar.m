%% u_plot.m

close all
clc
clear all

% Read the data file
load Laminar_BL;

%% Data File Content
% Laminar_BL.m contains u, i.e. the x-component of the velocity at five
% locations stored in five variables: U1l, U2l,...,U5l. The number 
% indicates the spatial streamwise position and "l" indicates laminar.
% Each column corresponds to a point in the wall normal direction
% (totally 46 points), and each row a sample (totally 4003). 
% The y-coordinates of the points are stored in the vector t and the times 
% at which the values are sampled are stored in tl. 

% This file shows how the data can be loaded into Matlab, ploted, and how
% various informative values can be calculated. The file is NOT complete 
% for the assignment. Study the commands and what happens, copy, and look
% for other useful commands in order to compute and vissualize according to
% the instructions. Type help followed by a commande, e.g. "help length" in
% the command prompt to get information about the command.

% Reuse the file (copy to a new) for the turbulent flow (Turbulent_BL.mat),
% note though that for this there are data sampled at four streamwise 
% locations stored in U1t, U2t, U3t and U4t, and that the number of points 
% in the wall normal directions differs. Otherwise data can be handled in 
% the same way.
% 

%%
N = length(U1l(:,1));  %Number of samples obtained as the length of a (the first) column
V = 50; % Freestream velocity


%% Plot of instantantaneous u-velocity
% Note the different scales in the plots!
% Store the size of the screen
scrsz = get(0,'ScreenSize');
% Specify the size and position of the plot. 
figure('Position',[100 50 scrsz(3)/3 scrsz(4)*.75]) 
% Sublot is used for several plots in the same window.
% Syntax: subplot(# plots vertically, # plots horiz, plot nr)
subplot(2,1,1)
% Plot the u-velocity signals at the first, second, third, fourth, and fifth
% point at the first spatial position vs time. Note that several curves can
% be showed in the same diagram. 
% 'r', 'g', 'b' etc specify the color of the line. 
plot(tl,U1l(:,1),'r',tl,U1l(:,2),'g',tl,U1l(:,3),'b',tl,U1l(:,4),'c',tl,U1l(:,5),'m');
% Label the lines
legend('y=5.7 \mum','y=15.5\mum','y=26.8\mum','y=38.5\mum','y=50.2\mum')
% Set the properties of the axes, e.g. scale. 
set(gca,'XLim',[0 tl(length(tl))],'YLim', [0 10])
% Title and lables of the axes. Change the text to what you plot!
title('Instantaneous x-velocity @ .3 m from LE')
xlabel('Time [s]');
ylabel('[m/s]');

subplot(2,1,2)
plot(tl,U1l(:,10),'r',tl,U1l(:,20),'g',tl,U1l(:,30),'b',tl,U1l(:,40),'c',tl,U1l(:,46),'m');
legend('y=122 \mum','y=554 \mum','y=1.7 mm','y=12 mm','y=30 mm')
set(gca,'XLim',[0 tl(length(tl))],'YLim', [0 60])
title('Instantaneous x-velocity @ .3 m from LE')
xlabel('Time [s]');
ylabel('[m/s]');

%% Calculation and plot of velocity profiles
for i=1:46
    % Time averages
    U1la(i) = mean(U1l(:,i));
 
end

% Possible plot of the velocity profiles
figure('Position',[900 200 scrsz(3)/3 scrsz(4)/3]) 
plot(U1la,yl,'-r')
xlabel('[m/s]')
ylabel('y [m]')


%% Calculation of boundary layer thickness

% Experimental 

% Theoretical 

%% Calculation of skin friction

% tau1 = ...;

x1 = [.1 .2 .3 .4 .5];
% figure('Position',[700 300 scrsz(3)/3 scrsz(4)/3]) 
% plot(x1,cf,'-*r',x1,cf_theory,'-*b');
% legend('C_{f,test}','C_{f,theory}');
% % set(gca,'YLim',[0 .005])
% xlabel('Distance from LE [m]');
% ylabel('C_f [ - ]')
% title('Skin Friction Coefficient - Laminar Flow')


